#NAF
def naf():
    print("""The most prefereable books in the New Adult 
Fiction genre are A Court of Mist and Fury, Point of Retreat,                       
The Year We Fell Down and Eyes Turned Skyward. 


You can visit the New Adult Fiction category for more
New Adult Fiction books.

Thank you for visiting the Library. Have a great day.""")
