#Poe
def poe():
    print("""The most prefereable books in the Poetry
genre are Leaves of Grass, The Essential Rumi, The Wild 
Fox of Yemen and Life on Mars.

You can visit the Poetry category for more Poetry books.

Thank you for visiting the Library. Have a great day.""")
