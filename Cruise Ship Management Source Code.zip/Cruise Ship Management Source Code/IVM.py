#IVM
def ivm():
    print("""Indian Vegeterian Meal
    This meal is available for vegetarian passengers.
    It is usually aromatic and spicy, and incorporates flavours from the
    Indian sub‑continent.It can contain all types of vegetables, fresh fruit,
    dried fruits, legumes, dairy products, tofu, cereal, grains and vegetarian gelatine.
    It does NOT contain any type of meat or by‑products, fish, shellfish, eggs or
    animal gelatine.""")



























