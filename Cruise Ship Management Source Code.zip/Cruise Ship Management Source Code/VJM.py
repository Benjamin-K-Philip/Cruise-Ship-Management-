#VJM
def vjm():
    print("""             Vegeterian Jain Meal
This meal is available for members of the Jain community who are
pure vegetarians. It is prepared with a selection of Indian condiments. 
It can contain fresh fruit, vegetables that grow above ground, tofu, pulses,
cereals and rice.  It does NOT contain animal products and by‑products, seafood
eggs, dairy products, and root vegetables such as onions, mushrooms, ginger,
garlic, potatoes, carrots, radishes and turmeric.""")






























