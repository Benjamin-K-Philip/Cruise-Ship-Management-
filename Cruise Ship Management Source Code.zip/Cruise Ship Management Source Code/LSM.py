#LSM
def lsm():
    print("""                      Low Salt Meal
This meal is available for passengers requiring a diet low in salt or sodium.
It can contain meat, poultry or fish with no added salt, eggs and egg products,
milk and dairy products, rice and pasta (with no salt added during cooking),
fruits, vegetables, herbs, spices. 
It does NOT contain salty cheese, meat, fish or vegetables that have been smoked,
salted, cured or brined, condiments with added salt (e.g. soya sauce, ketchup),
salted nuts, seasoned salts, and salt substitutes.""")



































