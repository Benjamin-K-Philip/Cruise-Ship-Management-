#GN
def gn():
    print("""The most prefereable books in the Graphic Novel
genre are Watchmen, The Complete Persepolis, V for Vendetta and
American Born Chinese.
                 
You can visit the Graphic Novel category for more Graphic
Novel books.

Thank you for visiting the Library. Have a great day.""")
