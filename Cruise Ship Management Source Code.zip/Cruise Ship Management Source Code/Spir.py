#Spir
def spir():
    print("""The most prefereable books in the Spirtuality 
genre are The Art of Happiness, The Road Less Traveled, A Course 
in Miracles and Jonathan Livingstone Seagull.

You can visit the Spirtuality category for more
Spirtuality  books.

Thank you for visiting the Library. Have a great day.""")
