#Nov
def nov():
    print("""The most prefereable books in the
Novel genre are A Passage to India, David Copperfield, 
The Good Solider, Invisible Man.

You can visit the Novel category for more Novel books.

Thank you for visiting the Library. Have a great day.""")
