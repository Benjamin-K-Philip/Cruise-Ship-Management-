#YAF
def yaf():
    print("""The most prefereable books in the Young adult fiction
genre are Lord of the Flies , The Catcher in the Eye, The Hunger Games
and Divergent.
                 
You can visit the Young adult fiction category for more
Young adult fiction books.

Thank you for visiting the Library. Have a great day.""")
