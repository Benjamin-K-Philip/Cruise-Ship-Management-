#DM
def dm():
    print("""             Diabetic Meal
This is a low‑sugar meal for passengers with diabetes, or those requiring
low sugar diet.
It can contain lean meat, fish, wholegrain breads and cereals (brown rice,
whole meal pasta, quinoa, barley), starchy vegetables, legumes, fresh fruit,
low‑fat dairy products, plant‑based oils, and diabetic‑friendly products such as
sugar‑free jam.
It does NOT contain white bread, white pasta, candies, fried foods,
full‑fat sweetened dairy products, cream‑based sauces and fruits in syrup.""")




































