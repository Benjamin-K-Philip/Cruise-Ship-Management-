#His
def his():
    print("""The most prefereable books in the History
genre are Long Walk to Freedom, Caesar and Christ, Inglorious
Empire and The Rise and Fall of the Third Reich. 
                 
You can visit the History category for more History books.

Thank you for visiting the Library. Have a great day.""")
