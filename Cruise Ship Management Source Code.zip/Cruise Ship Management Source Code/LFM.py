#LFM
def lfm():
    print("""                   Low Fat Meal
This meal is available for passengers who require a diet low in fat.
It can contain lean meat, skinless poultry, lean fish, egg whites, rice, potatoes,
wholegrain breads and cereals, fresh fruits, vegetables and low‑fat dairy. Minimal
amounts of plant based oil may be used to prevent sticking.
It does NOT contain fried foods, processed meats, added fats (butter, cream),
creamy or cheesy sauces, egg yolks, oily fish, processed cheese.""")


























