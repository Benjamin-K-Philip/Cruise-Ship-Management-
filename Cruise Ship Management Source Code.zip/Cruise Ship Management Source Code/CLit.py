#CLit
def clit():
    print("""The most prefereable books in the Children's 
Literature genre are Charloett's Web, A Wrinkle in Time, 
The Tale of Peter Rabbit and Curious George.                  

You can visit the Children's Literature category for more
Children's Literature books.

Thank you for visiting the Library. Have a great day.""")

