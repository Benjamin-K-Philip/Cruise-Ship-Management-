#NSG
def nsg():
    print("""To play New School games you will 
need an arcade card for which you will need to fill  
credit in the card in order to swipe and play the
game of your choice.
The credit can only be accessible in US currency
i.e. in Dollars.
Playing New School games makes you to explore
and have fun with games in this era of digital age.

Thank you for visiting the Arcade. Have a great day.""")
