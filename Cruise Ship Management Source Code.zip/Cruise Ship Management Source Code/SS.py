#SS
def ss():
    print("""The most prefereable books in the Short Story
genre are Fragile Things, The Lottery, The Yellow Wall Paper 
and Runway.
                     
You can visit the Short Story category for more Short Story
books.

Thank you for visiting the Library. Have a great day.""")
