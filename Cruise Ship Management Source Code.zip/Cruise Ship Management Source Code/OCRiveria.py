#OCRiveria
import time
def OC():
    print("""Below are the factilites that the Cruise Ship in Oceania Riveria provides
                 \n \tInternational buffet dinner
The cruise has authentic folk dance performances like Youwla and Tanoura.
Complimentary Wi-fi connectivity for all its guests on board.
Souvenirs are available on sale for all its guests along with beautiful
traditional henna painting,and regular live Arabic performances.
                """)
    time.sleep(2)
    print("""     \n \tCruise Ship in MSC Virtuoso 
MSC Virtuosa will offer a superb choice of entertainment for the whole family,
from days in the water park or sports center to evenings in the super-amusement
park or the multi-purposekaraoke bar, comedy club, TV studio & bar.
                  """)
    time.sleep(2)
    print("""   \n \tCruise Ship in MSC Opera 
Choose from a superb selection of leisure and entertainment options throughout
each day and night of your cruise. Whatever your preference, from watching
spectacular shows or playing video games to shopping or working out,
you’ll always be able to find the ideal activity to satisfy your desire.
Teatro dell'Opera
Med Pearl Casino
Byblos Discoteca
Virtual Arcade
Shopping Area""")




