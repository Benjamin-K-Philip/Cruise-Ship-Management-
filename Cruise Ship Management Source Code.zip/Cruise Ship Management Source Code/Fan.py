#Fan
def fan():
    print("""The most prefereable books in the Fantasy
genre are The Name of the Wind, The Fifth Season, The Eye of
the World and A Game of Thrones.

You can visit the Fantasy category for more Fantasy books.

Thank you for visiting the Library. Have a great day.""")
