#BM
def bm():
    print("""                      Bland Meal
This meal is available for passengers who suffer from gastric discomfort.
It contains low‑fat foods, is non‑spicy and is easily digestible.
It can contain lean meat, fish, cooked vegetables, fruits, eggs and egg products,
white bread, white rice and low‑fat dairy products.
It does NOT contain raw vegetables such as onions, cabbage and cauliflower, spices
(such as black pepper or chilli), fried foods, whole grains, highly
seasoned foods.""")




















