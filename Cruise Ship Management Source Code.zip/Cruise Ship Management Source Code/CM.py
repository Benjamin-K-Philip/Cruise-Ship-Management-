#CM
def cm():
    print("""                        Child Meal
This meal is available for children between the ages of 2 and 12 years.
A special request for a vegetarian child meal can be made.It can contain
chicken,fish, meat, pasta, rice, milk and dairy products,eggs,
vegetables,fruit and fruit juices, crackers, chocolate, and crisps. It
does NOT contain highly seasoned food, rich sauces, whole grapes,
and hard candies.""")






























