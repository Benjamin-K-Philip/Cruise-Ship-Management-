#NVHM
def nvhm():
    print("""         Non-Vegeterian Hindu Meal
This meal is available for passengers who follow Hindu custom. Meals are
non‑vegetarian and prepared in Indian culinary style. It can contain lamb,
chicken, fish, eggs, milk, dairy products and cereals. It does NOT contain veal,
beef or by‑products, or raw or smoked fish.""")





























