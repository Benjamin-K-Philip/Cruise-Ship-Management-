#Comic
def comic():
    print("""The most prefereable books in the Comic 
genre are The Adventures of Tintin, The One Summer, Asteriz the
Gaul, The Underwater Welder. 

You can visit the Comic category for more  books.

Thank you for visiting the Library. Have a great day.""")
