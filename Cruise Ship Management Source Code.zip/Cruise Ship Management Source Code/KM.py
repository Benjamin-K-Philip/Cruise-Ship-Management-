#KM
def km():
    print("""                   Kosher Meal
For passengers who follow Jewish custom. Kosher meals are prepared to comply
with Jewish dietary requirements. Passover meals cannot be guaranteed.""")






































