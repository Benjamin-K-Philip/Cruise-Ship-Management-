#Arcrink
def arcrink():
    print("""Below are the entertainments available in the cruise ship:
1.)Arcade
2.)Water park
3.)Football ground,Basketball Court,Tennis courts
4.)Billiards,Carrom,Chess
5.)Library
6)Ice skating rink""")


























