#BabyM
def babym():
    print("""                  Baby Meal
This meal is available on board for infants less than 2 years old. A standard range
of proprietary brands of baby meals is available on board. Milk formula is also
available, however we encourage parents to carry food familiar to and preferred
by their babies.
Please note that we cannot sterilise bottles or provide sterilised water on
board, however bottled water is available.
It can contain strained food, vegetables and meats.
It does NOT contain any solid food, highly seasoned food, wheat, eggs,
fish or seafood.""")



















