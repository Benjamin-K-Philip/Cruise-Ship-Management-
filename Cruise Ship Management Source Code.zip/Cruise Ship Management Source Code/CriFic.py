#CriFic
def crific():
    print("""The most prefereable books in the Crime fiction 
genre are The Silent Patient, The Interview, The Shape of Water and
The Lincoln Lawyer.                  

You can visit the Crime fiction category for more Crime
ficiton books.

Thank you for visiting the Library. Have a great day.""")
