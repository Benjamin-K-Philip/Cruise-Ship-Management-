#Phil
def phil():
    print("""The most prefereable books in the Philosophy 
genre are Beyond Good and Evil, Being and Nothingness,
On the Genealogy of Morality and Critique of Pure Reason.

You can visit the Philosphy category for more Philosphy books.

Thank you for visiting the Library. Have a great day.""")
