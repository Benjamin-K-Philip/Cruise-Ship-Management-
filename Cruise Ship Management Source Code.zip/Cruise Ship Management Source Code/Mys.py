#Mys
def mys():
    print("""The most prefereable books in the Mystery
genre are The Da Vinci Code, In The Woods, The Detective and
Case Histories.

You can visit the Mystery category for more Mystery books.

Thank you for visiting the Library. Have a great day.""")
