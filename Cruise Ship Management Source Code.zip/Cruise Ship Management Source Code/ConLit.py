#ConLit
def conlit():
    print("""The most prefereable books in the Contemporary 
Literature genre are Never Let Me Go, The Kite Runner, A Thousand
Splendid Suns and Life of Pi.                  

You can visit the Contemporary Literature category for more
Contemporary Literature books.

Thank you for visiting the Library. Have a great day.""")

