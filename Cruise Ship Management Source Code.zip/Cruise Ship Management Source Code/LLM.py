#LLM
def llm():
    print("""                         Low Lactose Meal
This meal is available for passengers requiring a lactose restricted meal.
This meal is not suitable for passengers with a milk allergy.
It can contain meat, poultry, fish, eggs, fruits, vegetables, soy products
(tofu, soy yoghurts, soy cheeses), pasta, rice, potatoes, pulses, cow’s milk
alternatives (soy, oat, almond, coconut), milk‑free coffee creamers.
It does NOT contain cow’s milk products (milk, yoghurt, butter, cream, cheese, ghee,
kefir, ice cream), dairy‑based soups or sauces, bakery or pastry items containing
milk (croissants, muffins, cakes).""")

























