#GFM
def gfm():
    print("""                        Gluten Friendly Meal
This meal is available for passengers who require a gluten friendly meal.
This meal does not contain ingredients or food items with gluten. However our
hub and global caterers are not dedicated, certified GF facilities.
"It can contain meat, fish, seafood, poultry, eggs, dairy products, fruits,
vegetables,legumes, corn, rice, potatoes, quinoa, buckwheat, tapioca,
and gluten‑free breads and cakes.
It does NOT contain cereals containing gluten (including oats), products derived
from cereals containing gluten (flour, starch, semolina), soups or sauces containing
gluten (including soya sauce), and bakery or confectionary items
containing gluten.""")























