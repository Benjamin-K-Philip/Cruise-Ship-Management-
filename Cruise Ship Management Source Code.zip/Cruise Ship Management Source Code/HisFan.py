#HisFan
def hisfan():
    print("""The most prefereable books in the Historical
Fantasy genre are The Night Circus, The Dragon Republic, The Bear
and the Nightingale and Outlander.

You can visit the Historical Fantasy category for more
Historical Fantasy books.

Thank you for visiting the Library. Have a great day.""")
