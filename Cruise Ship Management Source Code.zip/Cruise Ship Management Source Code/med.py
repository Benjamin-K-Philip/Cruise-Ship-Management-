#med
def Med():
    print("""The major ocean cruise companies all have on board medical departments.
These medical bays can provide you with sea sickness or injuries and
help facilitate a medical evaluation in the case of more serious illness
or a medical emergenency""")






























