#Fic
def fic():
    print("""The most prefereable books in the Fiction
genre are The Great Gatsby, Adventures of Huckleberry Fin,
Pride and Prejudice and War and Peace.

You can visit the Fiction category for more Fiction books.

Thank you for visiting the Library. Have a great day.""")
