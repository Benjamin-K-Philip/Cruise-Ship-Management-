#RG
def rg():
    print("""To play Retro games you will need to have 
tokens where the tokens are also known quarters i.e. 25 cents
in dollars(United States Currency).
Playing Retro games makes you visit your old fun
lived memories in the Arcade with the games you
used to play.

Thank you for visiting the Arcade. Have a great day.""")
