#AdFic
def adfic():
    print("""The most prefereable books in the Adventure fiction
genre are Treasure Island, Around the World in Eighty Days,King 
Solomon's Mines and Gulliver's Travels
                 
You can visit the Adeventure fiction category for more
Adeventure fiction books.

Thank you for visiting the Library. Have a great day.""")
