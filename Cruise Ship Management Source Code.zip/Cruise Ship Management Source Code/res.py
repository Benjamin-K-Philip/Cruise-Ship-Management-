#res
def Res():
    print("""1.)Nuska Beach
2.)Bastion
3.)Dhow and Anchor
4.)Kitchen Connections")
5.)Creations Cakery
6.)Fika
7.)Floor 24
8.)Murray's""")

