#FT
def ft():
    print("""The most prefereable books in the Fairy Tale 
genre are Puss in Boots, Spinning Silver, The Hazel Wood and
The Hobbit.

You can visit the Fairy Tale category for more Fairy
Tale books.

Thank you for visiting the Library. Have a great day.""")
